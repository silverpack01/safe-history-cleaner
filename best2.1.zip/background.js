let blockedKeywords = [];
const REMOTE_KEYWORD_URL =
    "https://raw.githubusercontent.com/StevenBlack/hosts/refs/heads/master/hosts";

// 🔹 Extra smart related keywords
const relatedAdultWords = [
    "18+", "nsfw", "adult", "uncensored", "naked", "nude", "explicit",
    "uncen", "uncensor", "sexy", "provocative", "mature", "not censored",
    "sensual", "xxx", "x-rated", "sexual", "animation", "cartoon", "hot",
    "girl", "fetish", "pleasure", "fantasy", "ecchi", "lewd", "hentai", "hentai heaven",
    "hanime", "uncensored hentai", "rule34"
];

// 🔹 Load keywords (local + optional remote update)
async function loadKeywords() {
    try {
        const localResponse = await fetch(browser.runtime.getURL("blocked.json"));
        const localData = await localResponse.json();
        blockedKeywords = Array.isArray(localData) ? localData : localData.keywords || [];
        console.log("✅ Local blocked.json loaded:", blockedKeywords.length);
    } catch (err) {
        console.warn("⚠️ Failed to load local blocked.json:", err);
    }

    try {
        const response = await fetch(REMOTE_KEYWORD_URL, { cache: "no-store" });
        if (response.ok) {
            const rawText = await response.text();
            const remoteData = rawText
                .split("\n")
                .map(line => line.trim())
                .filter(line => line && !line.startsWith("#"))
                .map(line => {
                    const parts = line.split(/\s+/);
                    return parts.length > 1 ? parts[1] : parts[0];
                })
                .filter(domain => domain && domain.includes("."));
            blockedKeywords = [...new Set([...blockedKeywords, ...remoteData])];
            console.log("🌐 Remote keyword list merged:", blockedKeywords.length);
            await browser.storage.local.set({
                blockedKeywordsCache: blockedKeywords,
                lastUpdate: Date.now(),
            });
        }
    } catch (err) {
        console.warn("⚠️ Remote keyword update failed:", err);
        const cache = await browser.storage.local.get("blockedKeywordsCache");
        if (cache.blockedKeywordsCache) {
            blockedKeywords = cache.blockedKeywordsCache;
            console.log("♻️ Loaded from cache:", blockedKeywords.length);
        }
    }
}

// 🔹 Normalize & decode text
function normalizeText(text) {
    try {
        let decoded = text;
        while (decoded.includes("%")) decoded = decodeURIComponent(decoded);
        decoded = decoded.replace(/[^\w\s:/?.=&-]/g, "").toLowerCase();
        return decoded;
    } catch {
        return text.toLowerCase();
    }
}

// 🔹 Sentence analyzer
function isAdultSentence(sentence) {
    const text = normalizeText(sentence);
    let adultHits = 0;

    for (const keyword of blockedKeywords) {
        if (!keyword) continue;
        const regex = new RegExp(`\\b${keyword}\\b`, "i");
        if (regex.test(text)) adultHits++;
    }

    for (const word of relatedAdultWords) {
        if (text.includes(word)) adultHits++;
    }

    return adultHits >= 1; // 1 match bhi adult consider kar le
}

// 🔹 Core delete logic
async function checkAndDelete(url, title = "") {
    if (!url) return false;

    // Fix malformed URLs like "httpswwwgooglecomsearch..."
    url = url.replace(/^https\s+/, "https://").replace(/^http\s+/, "http://").replace(/\s+/g, "");

    const combinedText = normalizeText(url + " " + (title || ""));

    try {
        const urlObj = new URL(url);

        // ✅ Google search queries
        if (urlObj.hostname.endsWith(".google.com") || urlObj.hostname.includes(".google.")) {
                const query = normalizeText(urlObj.searchParams.get("q") || "");
            if (isAdultSentence(query) || isAdultSentence(combinedText)) {
                await browser.history.deleteUrl({ url });
                console.log("🗑️ Deleted adult-related Google search:", query);
                return true;
            }
        }

        // ✅ Normal URLs
        if (isAdultSentence(combinedText)) {
            await browser.history.deleteUrl({ url });
            console.log("🗑️ Deleted adult-related URL:", url);
            return true;
        }
    } catch (err) {
        // Malformed URL fallback: treat full text as potential adult
        if (isAdultSentence(combinedText)) {
            try {
                await browser.history.deleteUrl({ url });
                console.log("🗑️ Deleted malformed adult-related URL/text:", combinedText);
                return true;
            } catch {}
        }
    }
    return false;
}

// 🔹 Event listeners
browser.history.onVisited.addListener(async (item) => {
    await checkAndDelete(item.url, item.title);
});

browser.webNavigation.onCommitted.addListener(async (details) => {
    if (details.url && details.transitionType !== "auto_subframe") {
        setTimeout(() => checkAndDelete(details.url), 200);
    }
});

// 🔹 Periodic cleanup
async function cleanupHistory() {
    const since = Date.now() - 5 * 60 * 1000;
    const results = await browser.history.search({
        text: "",
        startTime: since,
        maxResults: 200,
    });
    for (const item of results) {
        await checkAndDelete(item.url, item.title);
    }
}
setInterval(cleanupHistory, 60 * 1000);

loadKeywords();

// 🔄 Auto-refresh keywords
setInterval(loadKeywords, 7 * 24 * 60 * 60 * 1000);
