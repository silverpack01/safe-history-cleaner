let blockedKeywords = [];

async function loadkeywords() {
    try {
        const response = await fetch(browser.runtime.getURL("blocked.json"));
        blockedKeywords = await response.json();
        console.log("✅ Keywords loaded:", blockedKeywords.length);
    } catch (err) {
        console.error("❌ Failed to load keywords:", err);
    }
}

function normalizeText(text) {
    try {
        return decodeURIComponent(text).toLowerCase();
    } catch {
        return text.toLowerCase();
    }
}

async function checkAndDelete(url) {
    const cleanUrl = normalizeText(url);

    try {
        const urlObj = new URL(cleanUrl);

        // ✅ Google searches
        if (urlObj.hostname.includes("google.") && urlObj.pathname.includes("/search")) {
            const query = normalizeText(urlObj.searchParams.get("q") || "");
            for (const keyword of blockedKeywords) {
                if (query.includes(keyword) || cleanUrl.includes(keyword)) {
                    await browser.history.deleteUrl({ url });
                    console.log("🗑️ Deleted Google search with keyword:", keyword);
                    return true;
                }
            }
        }

        // ✅ Normal URLs
        for (const keyword of blockedKeywords) {
            if (cleanUrl.includes(keyword)) {
                await browser.history.deleteUrl({ url });
                console.log("🗑️ Blocked URL deleted:", url);
                return true;
            }
        }
    } catch (err) {
        console.error("URL parsing error:", err);
    }
    return false;
}

// 🔹 Listener for new history entries
browser.history.onVisited.addListener(async (historyItem) => {
    await checkAndDelete(historyItem.url);
});

// 🔹 Listener for navigation (instant reaction 🚀)
browser.webNavigation.onCommitted.addListener(async (details) => {
    if (details.url && details.transitionType !== "auto_subframe") {
        await checkAndDelete(details.url);
    }
});

// 🔹 Extra safeguard: cleanup every 2 minutes
async function cleanupHistory() {
    const since = Date.now() - 2 * 60 * 1000;
    const results = await browser.history.search({
        text: "",
        startTime: since,
        maxResults: 100
    });

    for (const item of results) {
        await checkAndDelete(item.url);
    }
}

setInterval(cleanupHistory, 2 * 60 * 1000);

// ✅ Load keywords at startup
loadkeywords();

// 🔄 Refresh keywords every 5 minutes
setInterval(loadkeywords, 5 * 60 * 1000);
